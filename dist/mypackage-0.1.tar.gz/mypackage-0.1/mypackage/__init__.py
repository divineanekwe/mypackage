# from . import myModule
from .myModule import top_n  # access top_n directly from the package name